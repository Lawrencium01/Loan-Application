<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from jituchauhan.com/borrow/bootstrap-4/index-4-students-loan.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 31 Mar 2020 11:21:25 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Borrow - is the loan company, Business Website Template.">
    <meta name="keywords" content="students loan, education loan, loan">
    <title>Greater Height</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/fontello.css" rel="stylesheet">
   
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CMerriweather:300,300i,400,400i,700,700i" rel="stylesheet">
    <!-- owl Carousel Css -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    
    <!-- /.top-bar -->
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-lg-2 col-md-12 col-sm-6 col-6">
                    <!-- logo -->
                    <div class="logo">
                        <a href="index.php"><img src="images/Untitled design (1).png" alt="Borrow - Loan Company Website Template"></a>
                    </div>
                </div>
                <!-- logo -->
                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                     <div id="navigation">
                        <!-- navigation start-->
                        <ul>
                            <li class="active"><a href="#" class="animsition-link">Home</a>
                                <ul>
                                    <li><a href="index.php" title="Home page 1" class="animsition-link">Home page</a></li>
                                    
                                </ul>
                            </li>
                            <li><a href="#" class="animsition-link">Products</a>
                                <ul>
                                    
                                    <li><a href="index-5-business-loan.php" title="students loan" class="animsition-link">Savings page<span class="badge">New</span></a></li>
                                    <li><a href="investment.php" title="students loan" class="animsition-link">Investment Page<span class="badge">New</span></a></li>
                                    
                                </ul>
                            </li>
                            <li><a href="about.php" class="animsition-link">About us</a>
                                <ul>
                                    <li><a href="about.php" title="About us" class="animsition-link">About us</a></li>
                                    <li><a href="team.php" title="Team" class="animsition-link">Services</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="" class="animsition-link">Features</a>
                                <ul>
                                    
                                       
                                        
                                        <li><a href="faq.php" title="Faq" class="animsition-link">Faq page</a></li>
                                        <li><a href="testimonial.php" title="Testimonial" class="animsition-link">Testimonial</a></li>
                                        <ul>
                                                <li><a href="gallery-filter-2.php" title="Filterable Gallery 2 column" class="animsition-link">Filterable Gallery 2 column</a></li>
                                                <li><a href="gallery-filter-3.php" title="Filterable Gallery 3 column" class="animsition-link">Filterable Gallery 3 column</a></li>
                                                <li><a href="gallery-masonry.php" title="Masonry Gallery" class="animsition-link">Masonry Gallery</a></li>
                                                <li><a href="gallery-zoom.php" title="Zoom Gallery" class="animsition-link">Zoom Gallery</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li><a href="contact-us.php" title="Contact us" class="animsition-link">Contact us</a></li>
                                </ul>
                                </li>
                                <li><a href="loan-calculator.php" class="animsition-link">loan calculator</a>
                               
                        </ul>
                    </div>
                    <!-- /.navigation start-->
                </div>
            </div>
        </div>
    </div>
    
    
    
    
    <div class="section-space80 bg-gradient call-to-action">
        <div class="container">
            <div class="row">
                <div class="offset-xl-2 col-xl-8 offset-md-2 col-md-8 offset-md-2 col-md-8 col-sm-12 col-12">
                    <div class="section-title mb60 text-center">
                        <!-- section title start-->
                        <h1 class="text-white">Just take 2 minute for your loan</h1>
                        <p class="text-white">Fill up the form below and loan executive would get in touch with you</p>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
            <div class="row">
                <div class="offset-xl-2 col-xl-8 offset-md-2 col-md-8 offset-md-2 col-md-8 col-sm-12 col-12">
                    <div class="students-request-form">
                        <form id="frmobj">
							<input type="hidden" name="regtag" id="regtag" value="0">
                            <div class="row">
                                <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="name">Name</label>
                                    <input id="name" name="name" type="text" placeholder="Name" class="form-control input-md" required="">
                                </div>
                                <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="email">E-Mail</label>
                                    <input id="email" name="email" type="text" placeholder="E-mail" class="form-control input-md" required="">
                                </div>
                                <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Phone</label>
                                    <input id="phone" name="phone" type="text" placeholder="Phone" class="form-control input-md" required="">
                                </div>
                                <!-- Select Basic -->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="Residential_Address">Residential Address</label>
                                    <input id="r_address" name="r_address" type="text" placeholder="Residential_Address" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="Office/Shop_Address">Office/Shop Address</label>
                                    <input id="office_address" name="office_address" type="text" placeholder="Office/Shop_Address" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                               <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="DOB">Date Of Birth</label>
                                    <input id="dob" name="dob" type="date" placeholder="Date of Birth" class="form-control input-md" required="">
                                </div> 
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Valid ID detail</label>
                                    <input id="valid_id_detail" name="valid_id_detail" type="text" placeholder="Valid ID Detail" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Marital Status</label>
                                    <input id="marital_status" name="marital_status" type="text" placeholder=" Marital Status" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Nature Of Business</label>
                                    <input id="nature_of_business" name="nature_of_business" type="text" placeholder=" Nature Of Business" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">BVN</label>
                                    <input id="bvn" name="bvn" type="text" placeholder="BVN" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Place Of Work</label>
                                    <input id="place_of_work" name="place_of_work" type="text" placeholder="Place Of Work" class="form-control input-md" required="">
                                </div>
                                 <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="phone">Spouse Name</label>
                                    <input id="spouse_name" name="spouse_name" type="text" placeholder=" Spouse Name" class="form-control input-md" required="">
                                </div>
                                 <!-- Account Details-->
                                <div>
                                    <h2 style="color: white;" stlye="color">ACCOUNT DETAILS</h2>
                                </div> 
                            </div>
                            <div class="row">
                                <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="name">Bank Name/Account name & number</label>
                                    <input id="bankname_accountno" name="bankname_accountno" type="text" placeholder="Bank Name/Account name & number" class="form-control input-md" required="">
                                </div> 
								 <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="name">Reference Number</label>
                                    <input id="ref_no" name="ref_no" type="text" maxlength="10" class="form-control input-md">
                                </div>
                            </div>
                            <!-- Next of kin details-->
                            <div>
                                <h2 style="color: white;" stlye="color">NEXT OF KIN DETAILS</h2>
                            </div>
                            <div class="row">
                                <!-- Text input-->
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="name">Name</label>
                                    <input id="kin_name" name="kin_name" type="Bank_name" placeholder="Name" class="form-control input-md" required="">
                                </div>
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="Address">Address</label>
                                    <input id="kin_address" name="kin_address" type="text" placeholder="Address" class="form-control input-md" required="">
                                </div>
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="Phone/Email">Phone/Email</label>
                                    <input id="kin_phone_no" name="kin_phone_no" type="text" placeholder="Phone No/Email" class="form-control input-md" required="">
                                </div>
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                    <label class="control-label sr-only" for="Relationship">Relationship with Next of Kin</label>
                                    <input id="kin_relationship" name="kin_relationship" type="text" placeholder="Relationshp with Next of Kin" class="form-control input-md" required="">
                                </div>
                                <!-- Loan Details -->
                                <div>
                                    <h2 style="color: white;" stlye="color">LOAN DETAILS</h2>
                                </div>
                                <div class="row">
                                    <!-- Text input-->
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Loan_Amount">Loan Amount</label>
                                        <input id="loan_amount" name="loan_amount" type="text" placeholder="Loan Amount" class="form-control input-md" required="">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Purpose">Purpose of Loan</label>
                                        <input id="purpose_of_loan" name="purpose_of_loan" type="text" placeholder="Purpose of Loan" class="form-control input-md" required="">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Income">Monthly Income</label>
                                        <input id="monthly_income" name="monthly_income" type="text" placeholder="Monthly Income:N" class="form-control input-md" required="">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Repayment">Monthly Repayment</label>
                                        <input id="monthly_repayment" name="monthly_repayment" type="text" placeholder="Monthly Repayment:N" class="form-control input-md" required="">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Method">Repayment Period</label>
                                        <input id="repayment_period" name="repayment_period" type="text" placeholder="Repayment Period" class="form-control input-md" required="">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Source">Source of Repayment</label>
                                        <input id="source_of_repayment" name="source_of_repayment" type="text" placeholder="Source of Repayment" class="form-control input-md" required="">
                                    </div>
									 <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Source">Interest</label>
                                        <input id="interest" name="interest" type="text" class="form-control input-md" placeholder="Interest" readonly="true">
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <label class="control-label sr-only" for="Details">Details of Pre Signed Cheques</label>
                                        <input id="details_of_cheque" name="details_of_cheque" type="text" placeholder="Details of Pre sined Cheque" class="form-control input-md" required="">
                                    </div>
                                <!-- Button -->
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group">
                                    <button type="button" class="btn btn-default btn-block" id="btnsave">Submit</button>
                                </div>
								<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group">
                                    <button type="button" class="btn btn-default btn-block" id="btnprint">Print Offer Letter</button>
                                </div>
                                 
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer section-space100">
        <!-- footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                    .
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
                    <div class="row">
                   
                    <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                        <div class="newsletter-form">
                            <!-- Newsletter Form -->
                            <form action="https://jituchauhan.com/borrow/bootstrap-4/newsletter.php" method="post">
                                
                                <!-- /input-group -->
                            </form>
                        </div>
                        <!-- /.Newsletter Form -->
                    </div>
                </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
            <hr class="dark-line">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="widget-text mt40">
                        <!-- widget text -->
                        <p>Greater Height was birth as the loan arm of our product.
                            This name was approved by our clients (savers and investors) due to the fantastic experience they have with us over the years. Hence our mobile application was launched using the name .</p>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                <p class="address-text"><span><i class="icon-placeholder-3 icon-1x"></i> </span>52 Ijaiye Rd, Ogba 101232, Lagos </p>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+234 803-579-4364</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.widget text -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">News</a></li>
                            <li><a href="#">Faq</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-social mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="https://www.facebook.com/Ghtrustfinanceng?mibextid=ZbWKwL"><i class="fa fa-facebook"></i>Facebook</a></li>
                            <li><a href="https://www.instagram.com/ghtrustfinanceng?igsh=OGQ5ZDc2ODk2ZA=="><i class="fa fa-instagram"></i>Instagram</a></li>
                            <li><a href="https://wa.me/2348035794364"><i class="fa fa-whatsapp"></i>Whatsapp</a></li>
                            
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                    <p>© Copyright Greater Height | ALL RIGHTS RESERVED</p>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 text-right">
                    <p></p>
                </div>
            </div>
        </div>
    </div>
       <!-- back to top icon -->
    <a href="#0" class="cd-top" title="Go to top">Top</a>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/menumaker.js"></script>
  
    <!-- sticky header -->
    <script type="text/javascript" src="js/jquery.sticky.js"></script>
    <script type="text/javascript" src="js/sticky-header.js"></script>
    <!-- slider script -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/slider-carousel.js"></script>
    <script type="text/javascript" src="js/service-carousel.js"></script>
    <!-- Back to top script -->
    <script src="js/back-to-top.js" type="text/javascript"></script>
    <script src="js/jquery-ui.js"></script>
	<script src="js/jquery.js" type="text/javascript"></script>
    <script>
	/*
    $(function() {
        $("#slider-range-min").slider({
            range: "min",
            value: 3000,
            min: 1000,
            max: 5000,
            slide: function(event, ui) {
                $("#amount").val("$" + ui.value);
            }
        });
        $("#amount").val("$" + $("#slider-range-min").slider("value"));
    });
	*/
    </script>
    <script>
	/*
    $(function() {
        $("#slider-range-max").slider({
            range: "max",
            min: 1,
            max: 10,
            value: 2,
            slide: function(event, ui) {
                $("#j").val(ui.value);
            }
        });
        $("#j").val($("#slider-range-max").slider("value"));
    });
	*/
    </script>
	
	<script>
		$(document).ready(function() {      
			$("#loan_amount").keyup(function(){
				var value1 = parseFloat($("#loan_amount").val());
				
				var inte = value1 * 0.08;
				
				$("#interest").val(inte);
			});
		}); 
		
		function startup(){
			$("#name").val('');
			$("#email").val('');
			$("#phone").val('');
			$("#r_address").val('');
			$("#office_address").val('');
			$("#dob").val('');
			$("#valid_id_detail").val('');
			$("#marital_status").val('');
			$("#nature_of_business").val('');
			$("#bvn").val('');
			$("#place_of_work").val('');
			$("#spouse_name").val('');
			$("#bankname_accountno").val('');
			$("#kin_name").val('');
			$("#kin_address").val('');
			$("#kin_phone_no").val('');
			$("#kin_relationship").val('');
			$("#loan_amount").val('');
			$("#purpose_of_loan").val('');
			$("#monthly_income").val('');
			$("#monthly_repayment").val('');
			$("#repayment_period").val('');
			$("#source_of_repayment").val('');
			$("#details_of_cheque").val('');
			$("#interest").val('');
		}
		
		$(document).ready(function() {
			$("#ref_no").val(randomNumber());
			$("#btnreset").click(function(){
				startup();
			});
			
	   
			$("#btnsave").click(function(){
			   var bankname_accountno = $("#bankname_accountno").val().trim();
			   var ref_no = $("#ref_no").val().trim();
			   var name = $("#name").val().trim();
			   var email = $("#email").val().trim();
			   var phone = $("#phone").val().trim();
			   var r_address = $("#r_address").val().trim();
			   var office_address = $("#office_address").val().trim();
			   var dob = $("#dob").val().trim();
			   var valid_id_detail = $("#valid_id_detail").val().trim();
			   var marital_status	= 	$("#marital_status").val().trim();
			   var nature_of_business = $("#nature_of_business").val().trim();
			   var bvn = $("#bvn").val().trim();
			   var place_of_work = $("#place_of_work").val().trim();
			   var spouse_name = $("#spouse_name").val().trim();
			   var kin_name = $("#kin_name").val().trim();
			   var kin_address = $("#kin_address").val().trim();
			   var kin_phone_no = $("#kin_phone_no").val().trim();
			   var kin_relationship = $("#kin_relationship").val().trim();
			   var loan_amount = $("#loan_amount").val().trim();
			   var purpose_of_loan = $("#purpose_of_loan").val().trim();
			   var monthly_income = $("#monthly_income").val().trim();
			   var monthly_repayment = $("#monthly_repayment").val().trim();
			   var repayment_period = $("#repayment_period").val().trim();
			   var source_of_repayment = $("#source_of_repayment").val().trim();
			   var details_of_cheque = $("#details_of_cheque").val().trim();
			   var interest = $("#interest").val().trim();
			   if (bankname_accountno=='' ||ref_no==''|| name=='' || email=='' || phone=='' || r_address=='' || office_address=='' || dob=='' || valid_id_detail=='' || marital_status=='' || nature_of_business==''
					|| bvn=='' || place_of_work=='' || spouse_name==''  || kin_name=='' || kin_address=='' || kin_phone_no=='' || kin_relationship=='' || loan_amount=='' || purpose_of_loan==''
					|| monthly_income=='' || monthly_repayment=='' || repayment_period=='' || source_of_repayment=='' || details_of_cheque=='' || interest==''){
				   var msg = "One or more inputs are empty or not correct";
				   alert(msg);				
				}else{
				   var frmValues = $("#frmobj").serialize()+ "&PT="+'DC';
				   $.post("managestudentloan.php",frmValues).done(function(data){
					   if (data==1){
						   alert("Detail Successfully submit!");
						   $("#bankname_accountno").val('');
						   
						}else{
						   alert(data);
						}	
					});
				}
			});
		});
		
		function randomNumber() {
			
			let tenDigits = '';

			for (let i = 0; i < 10; i++) {
				tenDigits += Math.floor(Math.random() * 10);
			}
			return tenDigits;
		}

        $("#btnprint").click(function(){
			var ref_no 		=	$("#ref_no").val().trim();
			var name		=	$("#name").val().trim();
			var loan_amount 		=	$("#loan_amount").val().trim();
			var purpose_of_loan		=	$("#purpose_of_loan").val().trim();
			var repayment_period		=	$("#repayment_period").val().trim();
			var interest 		=	$("#interest").val().trim();
			var monthly_repayment 		=	$("#monthly_repayment").val().trim();
			var dob 		=	$("#dob").val().trim();
			var param ="ref_no="+ref_no+"&name="+name+"&loan_amount="+loan_amount+"&purpose_of_loan="+purpose_of_loan+"&repayment_period="+repayment_period+"&interest="+interest+"&monthly_repayment="+monthly_repayment+"&dob="+dob;
			window.location.href ="offerletter.php?"+param;
		});
		
	</script>
	
</body>


<!-- Mirrored from jituchauhan.com/borrow/bootstrap-4/index-4-students-loan.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 31 Mar 2020 11:21:28 GMT -->
</html>